# Author:haha

import random
'''
print(random.random())#取0-1的随机浮点数
#输出：0.07306541518636855
print(random.randint(1,3))#取[1,3]闭区间的整数
print(random.randrange(1,3))#取[1,3)半闭半开区间的整数
print(random.choice('abcde'))#随机取字符串中的字符
print(random.choice([1,2,3,4,5,6]))#随机取列表中的数据
print(random.sample('abcde',2))#随机取两位数据
#输出：['b', 'e']
print(random.uniform(1,3))#取（1,3）区间的浮点数
#输出：2.1186016630230196
a=[1,2,3,4,5,6]
random.shuffle(a)#随机打乱数据顺序
print(a)
#输出：[3, 1, 5, 6, 2, 4]
'''

checkcode = ''
for i in range(6):
    b_current = random.randrange(0,6)
    if b_current != i:
        s_current=random.randrange(0,6)
        if s_current==b_current:
            temp = chr(random.randint(97,122))
        else:
            temp = chr(random.randint(65,90))
    else:
        temp = random.randint(0,9)
    checkcode += str(temp)
print (checkcode)