# Author:haha

import shelve

f=shelve.open('./copy_file/buwexia')
class test:
    def __init__(self,n):
        self.n=n

t1=test(123)
t2=test(456)
print(t1)
name=['haha','enen','yoyo']
